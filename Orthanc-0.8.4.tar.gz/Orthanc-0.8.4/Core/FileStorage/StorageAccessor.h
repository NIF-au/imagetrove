/**
 * Orthanc - A Lightweight, RESTful DICOM Store
 * Copyright (C) 2012-2014 Medical Physics Department, CHU of Liege,
 * Belgium
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * In addition, as a special exception, the copyright holders of this
 * program give permission to link the code of its release with the
 * OpenSSL project's "OpenSSL" library (or with modified versions of it
 * that use the same license as the "OpenSSL" library), and distribute
 * the linked executables. You must obey the GNU General Public License
 * in all respects for all of the code used other than "OpenSSL". If you
 * modify file(s) with this exception, you may extend this exception to
 * your version of the file(s), but you are not obligated to do so. If
 * you do not wish to do so, delete this exception statement from your
 * version. If you delete this exception statement from all source files
 * in the program, then also delete it here.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 **/


#pragma once

#include "FileInfo.h"
#include "../HttpServer/HttpFileSender.h"

#include <vector>
#include <string>
#include <boost/noncopyable.hpp>
#include <stdint.h>

namespace Orthanc
{
  class StorageAccessor : boost::noncopyable
  {
  protected:
    bool storeMD5_;

    virtual FileInfo WriteInternal(const void* data,
                                   size_t size,
                                   FileContentType type) = 0;

  public:
    StorageAccessor()
    {
      storeMD5_ = true;
    }

    virtual ~StorageAccessor()
    {
    }

    void SetStoreMD5(bool storeMD5)
    {
      storeMD5_ = storeMD5;
    }

    bool IsStoreMD5() const
    {
      return storeMD5_;
    }

    FileInfo Write(const void* data,
                   size_t size,
                   FileContentType type)
    {
      return WriteInternal(data, size, type);
    }

    FileInfo Write(const std::vector<uint8_t>& content,
                   FileContentType type);

    FileInfo Write(const std::string& content,
                   FileContentType type);

    virtual void Read(std::string& content,
                      const std::string& uuid,
                      FileContentType type) = 0;

    virtual void Remove(const std::string& uuid,
                        FileContentType type) = 0;

    virtual HttpFileSender* ConstructHttpFileSender(const std::string& uuid,
                                                    FileContentType type) = 0;
  };
}
